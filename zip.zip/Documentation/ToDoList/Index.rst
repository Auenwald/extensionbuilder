﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


.. _todo:

To-Do list
==========

There are still many features missing. We will try to complete them step by step.

Pull requests are welcome: `ExtensionBuilder Github <https://github.com/FriendsOfTYPO3/extension_builder/issues>`_

If you have a missing feature which you consider useful in common use cases report it there.


If you want to participate in a great Open Source community, consider to contribute
to the ExtensionBuilder and become a team member!
