﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


.. _known-problems:

Known Problems
==============

There is an issue with the modeler if gridelements is installed.

Please report bugs in github:
`ExtensionBuilder Github <https://github.com/FriendsOfTYPO3/extension_builder/issues>`_
